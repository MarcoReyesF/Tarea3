package com.example.tareaandroid3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ConfirmarDatos extends AppCompatActivity {

    Button ButtonEditar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_datos);


        Bundle paramtros = getIntent().getExtras();
        String stNombre = paramtros.getString("Nombre");
        String stFecha = paramtros.getString("Fecha");
        String stTelefono = paramtros.getString("Telefono");
        String stEmail = paramtros.getString("Email");
        String stDesc = paramtros.getString("Descripcion");

        TextView tvNombre = (TextView) findViewById(R.id.textNombre);
        TextView vtFecha = (TextView) findViewById(R.id.textFecha);
        TextView tvTel = (TextView) findViewById(R.id.textTel);
        TextView tvEmail = (TextView) findViewById(R.id.textEmail);
        TextView tvDesc = (TextView) findViewById(R.id.textDescrip);

        tvNombre.setText(stNombre);
        vtFecha.setText(stFecha);
        tvTel.setText(stTelefono);
        tvEmail.setText(stEmail);
        tvDesc.setText(stDesc);

        ButtonEditar = (Button) findViewById(R.id.buttonEditar);
        ButtonEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editarDatos (v);
            }
        });

    }
    @Override
    protected void onStop(){
        super.onStop();
    }

    protected void onDestroy(){
        super.onDestroy();
    }

    public void editarDatos (View view){
        //finishActivity();
        //onBackPressed();
        //Intent princiapl = new Intent(this,MainActivity.class);
        //startActivity(princiapl);
        finish();
    }

}
