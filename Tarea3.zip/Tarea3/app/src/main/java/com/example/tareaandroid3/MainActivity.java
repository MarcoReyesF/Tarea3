package com.example.tareaandroid3;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {



    public EditText nombre,telefono, mail, desc;
    public final Calendar c = Calendar.getInstance();
    DatePicker simpleDatePicker;
    Button ButtonOk, ButtonCancel, ButtonSiguiente;
    String etFecha = "Sin Fecha";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombre = (EditText) findViewById(R.id.editTextNombre);
        telefono = (EditText) findViewById(R.id.editTextTelefono);
        mail = (EditText) findViewById(R.id.editTextMail);
        desc = (EditText) findViewById(R.id.editTextDescrip);

        simpleDatePicker = (DatePicker)findViewById(R.id.dpFechaDeNacimiento);
        // initiate a date picker
        ButtonOk = (Button) findViewById(R.id.buttonOk);
        ButtonOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etFecha = simpleDatePicker.getDayOfMonth() + "/"+ simpleDatePicker.getMonth() + "/" + simpleDatePicker.getYear();
                Toast.makeText(getApplicationContext(), etFecha + "\n",Toast.LENGTH_LONG).show();
            }
        });

        ButtonCancel = (Button) findViewById(R.id.buttonCancel);
        ButtonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etFecha = "Sin Fecha";
            }
        });
        ButtonSiguiente = (Button) findViewById(R.id.BotonSiguiente);
        ButtonSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Siguiente(v);
            }
        });
    }


    public void Siguiente (View view){
        Intent siguiente = new Intent(this,ConfirmarDatos.class);
        //int month = simpleDatePicker.getMonth();
        siguiente.putExtra("Nombre",nombre.getText().toString());
        siguiente.putExtra("Fecha",etFecha);
        siguiente.putExtra("Telefono",telefono.getText().toString());
        siguiente.putExtra("Email",mail.getText().toString());
        siguiente.putExtra("Descripcion",desc.getText().toString());
        startActivity(siguiente);

    }



}
